# UruguaiEscola
é o Uruguai, e é a escola, bão demais
